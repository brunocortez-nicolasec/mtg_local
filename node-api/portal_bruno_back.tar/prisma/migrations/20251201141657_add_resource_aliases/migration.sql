-- AlterTable
ALTER TABLE "public"."Resource" ADD COLUMN     "aliases" JSONB;
