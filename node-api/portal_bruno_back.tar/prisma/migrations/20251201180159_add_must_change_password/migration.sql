-- AlterTable
ALTER TABLE "public"."users" ADD COLUMN     "mustChangePassword" BOOLEAN NOT NULL DEFAULT false;
